In terminal go to:
..Project\capstone-app\
type:
npm run dev
Server will run on port 3000, app will run on port 3001 in browser.

node_modules might need to be installed.