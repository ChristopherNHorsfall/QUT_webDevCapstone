const images = {
    koala: "https://images.pexels.com/photos/5644378/pexels-photo-5644378.jpeg?auto=compress&cs=tinysrgb&w=800",
    seaRocks01: "https://images.pexels.com/photos/1447000/pexels-photo-1447000.jpeg?auto=compress&cs=tinysrgb&w=800&lazy=load",
    beach01: "https://images.pexels.com/photos/2292976/pexels-photo-2292976.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2",
    bush01: "https://images.pexels.com/photos/4846090/pexels-photo-4846090.jpeg?auto=compress&cs=tinysrgb&w=800"
};

export default images;