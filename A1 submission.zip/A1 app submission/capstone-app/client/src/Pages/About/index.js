export default function About() {
    return (
        <main>
            <p>main</p>
        </main>
      );
   }