export default function Register() {
    return (
        <main>
            <p>main</p>
        </main>
      );
   }