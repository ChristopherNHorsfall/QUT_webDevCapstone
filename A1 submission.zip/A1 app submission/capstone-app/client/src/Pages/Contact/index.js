export default function Contact() {
    return (
        <main>
            <p>main</p>
        </main>
      );
   }